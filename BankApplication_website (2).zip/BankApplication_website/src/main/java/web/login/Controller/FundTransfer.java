package web.login.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FundTransfer
 */
@WebServlet("/FundTransfer")
public class FundTransfer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FundTransfer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String accountNumber = request.getParameter("accountNumber");
	        String amount = request.getParameter("amount");
	        String description = request.getParameter("description");

	        String message;
	        if (accountNumber != null && !accountNumber.isEmpty() && amount != null && !amount.isEmpty()) {
	            // Mock the fund transfer process
	            // In a real application, this would involve database operations and business logic
	            message = "Transfer of ₹" + amount + " to account number " + accountNumber + " was successful.";
	        } else {
	            message = "Please fill in all required fields.";
	        }

	        // Set the message attribute to be displayed in the result section
	        request.setAttribute("message", message);

	        // Forward the request back to the form page to display the result message
	        
	    }	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
