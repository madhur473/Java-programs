package web.login.Controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.jni.Sockaddr;

import web.login.dao.RegisterDao;
import web.login.dao.RegisterDaoImp;
import web.login.model.Login;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("Username");
		String password=request.getParameter("Password");
		
		Login lobj=new Login(username, password);
		System.out.println("test1");
		List<Login> lstLogin=new ArrayList<Login>();
		
		lstLogin.add(lobj);
		
		RegisterDao rdao =new RegisterDaoImp();
		System.out.println("test2");
		boolean isValidUser=rdao.validateUser(lstLogin);
		System.out.println("");
		if(isValidUser=true)
		{
			response.sendRedirect("Dashboard.jsp");
		}
		else
		{
			response.sendRedirect("Error.jsp");
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
