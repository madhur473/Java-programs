package web.login.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import web.login.model.Recharge;
import web.login.model.Register;

/**
 * Servlet implementation class RechargeController
 */
@WebServlet("/RechargeController")
public class RechargeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RechargeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // Retrieve the selected plan from the request parameters
    String selectedPlan = request.getParameter("plan");

    // Determine the amount to deduct based on the selected plan
    float planAmount = 0;
    switch (selectedPlan) {
        case "plan1":
            planAmount = 100; // Set plan amount for Plan 1
            break;
        case "plan2":
            planAmount = 50; // Set plan amount for Plan 2
            break;
        // Add cases for other plans if needed
    }

    // Print the plan amount
    System.out.println(planAmount);

    // Get the current account balance from the session
    HttpSession session = request.getSession();
    float accountBalance = Float.parseFloat(session.getAttribute("accountBalance").toString());

    // Deduct the plan amount from the account balance
    accountBalance -= planAmount;

    // Update the account balance in the session
    session.setAttribute("accountBalance", accountBalance);

    // Redirect to a confirmation page
    response.sendRedirect("Confirmation.jsp");
}
		
	}


