package web.login.model;

public class Recharge {
	
	private String phoneNumber;
	private String provider;
	
	public void Recharge() {
		
	}

	public Recharge(String phoneNumber, String provider) {
		super();
		this.phoneNumber = phoneNumber;
		this.provider = provider;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}
	
	

}
